const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const WIDTH = canvas.width;
const HEIGHT = canvas.height;

const images = {};
const sounds = {};
let assetsLoaded = false;

let keys = {};
let state = "start";
let facingLeft = false;
let spriteIndex = 0;
let frameCount = 0;
let inputText = "";
let quizIndex = 0;
let correctCount = 0;
let usedIndices = [];

const GREEN_HEIGHT_OFFSET = 18;
const BALLOON_MARGIN = 3;
const BALLOON_HEIGHT_RATIO = 0.5;
const SCORE_FONT_SIZE = 36;
const PLAYER_JUMP_VY = -20;
const GRAVITY = 1.0;

const player = {
  x: 0,
  y: HEIGHT / 2,
  vx: 0,
  vy: 0,
  width: 32,
  height: 48,
  speed: 4,
  onGround: false
};

const assets = {
  background: "assets/background.png",
  ground: "assets/ground.png",
  house: "assets/house.png",
  player: "assets/player.png",
  balloon: "assets/balloon.png",
  quizBG: "assets/quizBG.png",
  heart: "assets/heart.png",
  x: "assets/x.png",
  correctSound: "assets/sounds/correct.mp3",
  wrongSound: "assets/sounds/wrong.mp3",
  completeSound: "assets/sounds/complete.mp3"
};

const quizzes = [
  { question: "나는 궁금한 게 많고, 스스로 질문을 잘해. 나는 누구일까?", answers: ["Inquirer", "inquirer"] },
  { question: "나는 다양한 지식을 쌓고, 폭넓게 배워. 나는 누구일까?", answers: ["Knowledgeable", "knowledgeable"] },
  { question: "나는 생각을 깊이 하고, 문제를 여러 관점에서 바라봐. 나는 누구일까?", answers: ["Thinker", "thinker"] },
  { question: "나는 내 생각을 말과 글로 잘 표현해. 나는 누구일까?", answers: ["Communicator", "communicator"] },
  { question: "나는 다양한 문화와 생각을 이해하고 존중해. 나는 누구일까?", answers: ["Open minded", "Open Minded", "Open-minded", "Open-Minded", "open minded", "open-minded"] },
  { question: "나는 다른 사람의 감정을 잘 이해하고 도와주려고 해. 나는 누구일까?", answers: ["caring", "Caring"] },
  { question: "나는 언제나 옳은 일을 하려고 해. 정직하고 책임감도 있어. 나는 누구일까?", answers: ["Principled", "principled"] },
  { question: "나는 새로운 도전을 두려워하지 않아. 실수해도 포기하지 않아. 나는 누구일까?", answers: ["Risk taker", "Risk Taker", "risk taker", "Risk-Taker", "risk-taker","Risk-taker"] },
  { question: "나는 나 자신을 잘 알고, 항상 더 나아지려고 해. 나는 누구일까?", answers: ["Reflective", "reflective"] },
  { question: "나는 몸과 마음의 균형을 중요하게 생각해. 나는 누구일까?", answers: ["Balanced", "balanced"] },
];

function loadImage(name, src) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload = () => { images[name] = img; resolve(); };
    img.src = src;
  });
}

function loadSound(name, src) {
  return new Promise(resolve => {
    const audio = new Audio(src);
    sounds[name] = audio;
    resolve();
  });
}

async function loadAssets() {
  const imagePromises = Object.entries(assets)
    .filter(([k]) => !k.includes("Sound"))
    .map(([k, v]) => loadImage(k, v));
  const soundPromises = Object.entries(assets)
    .filter(([k]) => k.includes("Sound"))
    .map(([k, v]) => loadSound(k, v));
  await Promise.all([...imagePromises, ...soundPromises]);
  assetsLoaded = true;
  init();
}

function init() {
  const groundY = HEIGHT - images.ground.height;
  const greenTop = groundY + GREEN_HEIGHT_OFFSET;
  player.x = 0;
  player.y = greenTop - player.height;
  setEventListeners();
  requestAnimationFrame(gameLoop);
}

function setEventListeners() {
  window.addEventListener("keydown", e => {
    keys[e.key] = true;
    if (state === "quiz") {
      if (e.key === "Backspace") inputText = inputText.slice(0, -1);
      else if (e.key === "Enter") checkAnswer();
      else if (e.key.length === 1 && /[가-힣a-zA-Z0-9\s]/.test(e.key)) inputText += e.key;
    }
  });

  window.addEventListener("keyup", e => {
    keys[e.key] = false;
  });
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

function update() {
  if (!assetsLoaded || state !== "start") return;

  const groundY = HEIGHT - images.ground.height;
  const greenTop = groundY + GREEN_HEIGHT_OFFSET;
  const playerGroundY = greenTop - player.height;

  player.vx = 0;
  if (keys["ArrowRight"] || keys["d"]) {
    player.vx = player.speed;
    facingLeft = false;
  }
  if (keys["ArrowLeft"] || keys["a"]) {
    player.vx = -player.speed;
    facingLeft = true;
  }

  if ((keys["ArrowUp"] || keys["w"]) && player.onGround) {
    player.vy = PLAYER_JUMP_VY;
    player.onGround = false;
  }

  player.vy += GRAVITY;
  player.y += player.vy;

  if (player.y < 0) player.y = 0;

  if (player.y >= playerGroundY) {
    player.y = playerGroundY;
    player.vy = 0;
    player.onGround = true;
  }

  player.x += player.vx;
  player.x = Math.max(0, Math.min(player.x, WIDTH - player.width));

  if (player.vx !== 0) {
    frameCount++;
    if (frameCount % 8 === 0) spriteIndex = (spriteIndex + 1) % 4;
  } else {
    spriteIndex = 0;
  }

  const houseX = WIDTH - images.house.width;
  const houseY = groundY + GREEN_HEIGHT_OFFSET - images.house.height;

  if (
    player.x + player.width > houseX &&
    player.y + player.height >= houseY
  ) {
    if ((keys[" "] || keys["Spacebar"])) {
      if (correctCount >= 10) {
        endGame();
      } else if (state !== "quiz") {
        startQuiz();
      }
    }
  }
}

function draw() {
  if (!assetsLoaded) return;

  ctx.clearRect(0, 0, WIDTH, HEIGHT);
  const groundY = HEIGHT - images.ground.height;
  const greenTop = groundY + GREEN_HEIGHT_OFFSET;
  const houseX = WIDTH - images.house.width;
  const houseY = greenTop - images.house.height;

  if (state === "start") {
    ctx.drawImage(images.background, 0, 0, WIDTH, HEIGHT);
    ctx.drawImage(images.ground, 0, groundY, WIDTH, images.ground.height);
    ctx.drawImage(images.house, houseX, houseY);

    const frameW = images.player.width / 2;
    const frameH = images.player.height / 2;

    let sx = 0;
    let sy = 0;

    if (player.vx !== 0 || player.vy !== 0) {
      sx = (spriteIndex % 2) * frameW;
      sy = Math.floor(spriteIndex / 2) * frameH;
    } else {
      // ⏸️ Idle frame: bottom-right
      sx = frameW;
      sy = frameH;
    }

    ctx.save();
    if (facingLeft) {
      ctx.translate(player.x + frameW, player.y);
      ctx.scale(-1, 1);
      ctx.drawImage(images.player, sx, sy, frameW, frameH, 0, 0, frameW, frameH);
    } else {
      ctx.drawImage(images.player, sx, sy, frameW, frameH, player.x, player.y, frameW, frameH);
    }
    ctx.restore();

    ctx.fillStyle = "white";
    ctx.font = `${SCORE_FONT_SIZE}px sans-serif`;
    ctx.textAlign = "left";
    ctx.fillText(`${correctCount}/10`, 10, 40);
  }

  else if (["quiz", "correct", "wrong", "complete"].includes(state)) {
    ctx.drawImage(images.quizBG, 0, 0, WIDTH, HEIGHT);

    if (state === "quiz" || state === "wrong") {
      const q = quizzes[quizIndex].question;
      const fontSize = adjustFontSize(q, WIDTH - 40, 40);
      ctx.font = `${fontSize}px fantasy`;
      ctx.fillStyle = "brown";
      ctx.textAlign = "center";
      ctx.fillText(q, WIDTH / 2, 75);

      const balloonW = WIDTH - BALLOON_MARGIN;
      const balloonH = images.balloon.height * BALLOON_HEIGHT_RATIO;
      const balloonX = (WIDTH - balloonW) / 2;
      const balloonY = HEIGHT - balloonH - 5;

      ctx.drawImage(images.balloon, balloonX, balloonY, balloonW, balloonH);

      const inputFontSize = adjustFontSize(inputText, balloonW - 20, 28);
      ctx.font = `${inputFontSize}px sans-serif`;
      ctx.fillStyle = "black";
      ctx.fillText(inputText, WIDTH / 2, balloonY + balloonH / 2 + 10);

      if (state === "wrong") drawScaled(images.x);
    }

    if (state === "correct" || state === "complete") {
      drawScaled(images.heart);
      if (state === "complete") {
        ctx.fillStyle = "yellow";
        ctx.font = "32px fantasy";
        ctx.textAlign = "center";
        ctx.fillText("축하합니다!", WIDTH / 2, HEIGHT / 2);
      }
    }
  }
}

function drawScaled(img) {
  let w = img.width;
  let h = img.height;
  let scale = 1;
  let yOffset = 0;

  if (img === images.heart) {
    w += 20;
    h += 20;
    scale = 1.3;
    yOffset = 30;
  }

  if (img === images.x) {
    w -= 30;
    h -= 30;
  }

  ctx.drawImage(
    img,
    WIDTH / 2 - (w * scale) / 2,
    HEIGHT / 2 - (h * scale) / 2 + yOffset,
    w * scale,
    h * scale
  );
}

function adjustFontSize(text, maxWidth, baseSize) {
  let size = baseSize;
  ctx.font = `${size}px fantasy`;
  while (ctx.measureText(text).width > maxWidth && size > 10) {
    size--;
    ctx.font = `${size}px fantasy`;
  }
  return size;
}

function startQuiz() {
  if (state !== "start") return;
  const available = quizzes.map((_, i) => i).filter(i => !usedIndices.includes(i));
  if (available.length === 0) return;
  quizIndex = available[Math.floor(Math.random() * available.length)];
  usedIndices.push(quizIndex);
  inputText = "";
  state = "quiz";
}

function checkAnswer() {
  const quiz = quizzes[quizIndex];
  const answer = inputText.trim();
  if (quiz.answers.includes(answer)) {
    state = "correct";
    correctCount++;
    sounds.correctSound.play();
    setTimeout(() => {
      correctCount >= 10 ? endGame() : resetToStart();
    }, 1000);
  } else {
    state = "wrong";
    sounds.wrongSound.play();
    setTimeout(() => {
      state = "quiz";
      inputText = "";
    }, 1000);
  }
}

function resetToStart() {
  const groundY = HEIGHT - images.ground.height;
  const greenTop = groundY + GREEN_HEIGHT_OFFSET;
  player.x = 0;
  player.y = greenTop - player.height;
  inputText = "";
  state = "start";
}

function endGame() {
  state = "complete";
  sounds.completeSound.play();
}

window.onload = () => {
  loadAssets();
};
